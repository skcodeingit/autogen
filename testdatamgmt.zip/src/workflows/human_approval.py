from enum import Enum
from typing import Dict, Any, Optional
from datetime import datetime
import asyncio

class ApprovalStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"

class ApprovalRequest:
    def __init__(self, scenario_id: str, step_id: str, context: Dict[str, Any]):
        self.id = f"{scenario_id}_{step_id}"
        self.scenario_id = scenario_id
        self.step_id = step_id
        self.context = context
        self.status = ApprovalStatus.PENDING
        self.created_at = datetime.now()
        self.responded_at: Optional[datetime] = None
        self.response_comments: Optional[str] = None
        self._event = asyncio.Event()
    
    async def wait_for_response(self, timeout: float = None) -> ApprovalStatus:
        """Wait for human response with optional timeout."""
        try:
            await asyncio.wait_for(self._event.wait(), timeout=timeout)
            return self.status
        except asyncio.TimeoutError:
            self.status = ApprovalStatus.TIMEOUT
            return self.status
    
    def respond(self, approved: bool, comments: str = None):
        """Record human response."""
        self.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.REJECTED
        self.response_comments = comments
        self.responded_at = datetime.now()
        self._event.set()

class HumanApprovalManager:
    """Manages human approval requests and responses."""
    
    def __init__(self):
        self.pending_approvals: Dict[str, ApprovalRequest] = {}
        self._lock = asyncio.Lock()
    
    async def create_approval_request(
        self,
        scenario_id: str,
        step_id: str,
        context: Dict[str, Any]
    ) -> ApprovalRequest:
        """Create a new approval request."""
        async with self._lock:
            request = ApprovalRequest(scenario_id, step_id, context)
            self.pending_approvals[request.id] = request
            return request
    
    async def get_approval(
        self,
        scenario_id: str,
        step_id: str,
        context: Dict[str, Any],
        timeout: float = None
    ) -> Dict[str, Any]:
        """Request and wait for human approval."""
        request = await self.create_approval_request(scenario_id, step_id, context)
        status = await request.wait_for_response(timeout)
        
        async with self._lock:
            if request.id in self.pending_approvals:
                del self.pending_approvals[request.id]
        
        return {
            "status": status.value,
            "comments": request.response_comments,
            "created_at": request.created_at.isoformat(),
            "responded_at": request.responded_at.isoformat() if request.responded_at else None
        }
    
    def respond_to_approval(self, request_id: str, approved: bool, comments: str = None):
        """Respond to a pending approval request."""
        if request_id not in self.pending_approvals:
            raise ValueError(f"Approval request {request_id} not found")
        
        request = self.pending_approvals[request_id]
        request.respond(approved, comments)
    
    def get_pending_approvals(self) -> Dict[str, Dict[str, Any]]:
        """Get all pending approval requests."""
        return {
            req_id: {
                "scenario_id": req.scenario_id,
                "step_id": req.step_id,
                "context": req.context,
                "created_at": req.created_at.isoformat()
            }
            for req_id, req in self.pending_approvals.items()
        }

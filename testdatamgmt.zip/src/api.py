from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import uvicorn
from scenarios.manager import ScenarioManager

app = FastAPI(title="Test Data Management API")
scenario_manager = ScenarioManager()

class ApprovalResponse(BaseModel):
    approved: bool
    comments: Optional[str] = None

class ScenarioRequest(BaseModel):
    request: str
    config: Dict[str, Any]

class ScenarioResponse(BaseModel):
    scenario_id: str
    status: str
    message: str

@app.post("/scenarios", response_model=ScenarioResponse)
async def create_scenario(scenario: ScenarioRequest):
    try:
        scenario_id = await scenario_manager.create_scenario(
            request=scenario.request,
            config=scenario.config
        )
        return ScenarioResponse(
            scenario_id=scenario_id,
            status="created",
            message="Scenario created successfully"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/scenarios/{scenario_id}/execute")
async def execute_scenario(scenario_id: str):
    try:
        results = await scenario_manager.execute_scenario(scenario_id)
        return {
            "status": "completed",
            "results": results
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/scenarios/execute-batch")
async def execute_multiple_scenarios(scenario_ids: List[str]):
    try:
        results = await scenario_manager.execute_multiple_scenarios(scenario_ids)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/scenarios/{scenario_id}")
async def get_scenario_status(scenario_id: str):
    status = scenario_manager.get_scenario_status(scenario_id)
    if status is None:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return status

@app.get("/scenarios")
async def list_scenarios():
    return scenario_manager.get_all_scenarios()

@app.delete("/scenarios/{scenario_id}")
async def cleanup_scenario(scenario_id: str):
    try:
        await scenario_manager.cleanup_scenario(scenario_id)
        return {"status": "success", "message": "Scenario cleaned up"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Human approval endpoints
@app.get("/approvals/pending")
async def list_pending_approvals():
    """Get all pending approval requests."""
    for coordinator in scenario_manager.coordinators.values():
        return coordinator.approval_manager.get_pending_approvals()
    return {}

@app.post("/approvals/{request_id}")
async def respond_to_approval(request_id: str, response: ApprovalResponse):
    """Respond to a pending approval request."""
    for coordinator in scenario_manager.coordinators.values():
        try:
            coordinator.approval_manager.respond_to_approval(
                request_id,
                response.approved,
                response.comments
            )
            return {"status": "success", "message": "Approval response recorded"}
        except ValueError:
            continue
    raise HTTPException(status_code=404, detail="Approval request not found")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

from typing import Dict, Any
import json
import os
from pathlib import Path

class LLMConfig:
    """Configuration manager for LLM settings."""
    
    def __init__(self, config_path: str = None):
        self.config_path = config_path or "config/llm_config.json"
        self.config: Dict[str, Any] = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or return defaults."""
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r') as f:
                return json.load(f)
        
        # Default configuration
        return {
            "default_llm": "ollama",
            "llm_configs": {
                "ollama": {
                    "model_name": "llama2",
                    "temperature": 0.0,
                    "max_tokens": 2000
                }
            }
        }
    
    def save_config(self) -> None:
        """Save current configuration to file."""
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    def get_llm_config(self, llm_type: str = None) -> Dict[str, Any]:
        """Get configuration for specified LLM type."""
        llm_type = llm_type or self.config["default_llm"]
        return self.config["llm_configs"].get(llm_type, {})

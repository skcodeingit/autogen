from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

class BaseLLM(ABC):
    """Base class for LLM implementations."""
    
    @abstractmethod
    async def generate(self, prompt: str, **kwargs) -> str:
        """Generate response from the LLM."""
        pass
    
    @abstractmethod
    def get_model_config(self) -> Dict[str, Any]:
        """Get the current model configuration."""
        pass
    
    @abstractmethod
    def update_config(self, config: Dict[str, Any]) -> None:
        """Update the model configuration."""
        pass

from typing import Any, Dict, Optional
from langchain_community.llms import Ollama
from .base import BaseLLM

class OllamaLLM(BaseLLM):
    """Ollama LLM implementation."""
    
    def __init__(self, model_name: str = "llama2", **kwargs):
        self.model_name = model_name
        self.config = kwargs
        self.llm = Ollama(model=model_name, **kwargs)
    
    async def generate(self, prompt: str, **kwargs) -> str:
        """Generate response using Ollama."""
        # Merge instance config with request-specific kwargs
        config = {**self.config, **kwargs}
        return await self.llm.agenerate([prompt])
    
    def get_model_config(self) -> Dict[str, Any]:
        """Get current model configuration."""
        return {
            "model_name": self.model_name,
            **self.config
        }
    
    def update_config(self, config: Dict[str, Any]) -> None:
        """Update model configuration."""
        self.config.update(config)
        # Reinitialize the LLM with new config
        self.llm = Ollama(model=self.model_name, **self.config)

from typing import Dict, Any, Type
from .base import BaseLLM
from .ollama import OllamaLLM

class LLMFactory:
    """Factory for creating LLM instances."""
    
    _llm_registry: Dict[str, Type[BaseLLM]] = {
        "ollama": OllamaLLM,
        # Add more LLM implementations here as needed
    }
    
    @classmethod
    def register_llm(cls, name: str, llm_class: Type[BaseLLM]) -> None:
        """Register a new LLM implementation."""
        cls._llm_registry[name] = llm_class
    
    @classmethod
    def create_llm(cls, llm_type: str, **kwargs) -> BaseLLM:
        """Create an LLM instance of the specified type."""
        if llm_type not in cls._llm_registry:
            raise ValueError(f"Unknown LLM type: {llm_type}")
        
        llm_class = cls._llm_registry[llm_type]
        return llm_class(**kwargs)
    
    @classmethod
    def available_llms(cls) -> list[str]:
        """Get list of available LLM implementations."""
        return list(cls._llm_registry.keys())

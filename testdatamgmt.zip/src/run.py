import subprocess
import sys
import time
from pathlib import Path

def main():
    # Start the API server
    api_process = subprocess.Popen(
        [sys.executable, "src/api.py"],
        cwd=Path(__file__).parent.parent
    )
    
    # Wait for API server to start
    time.sleep(2)
    
    try:
        # Start the desktop application
        from ui.desktop_app import main as run_desktop_app
        run_desktop_app()
    finally:
        # Cleanup
        api_process.terminate()
        api_process.wait()

if __name__ == "__main__":
    main()

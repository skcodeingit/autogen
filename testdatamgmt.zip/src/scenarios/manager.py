from typing import Dict, Any, Optional
import uuid
import asyncio
from datetime import datetime
from agents.coordinator import WorkflowCoordinator

class ScenarioManager:
    """Manages multiple concurrent test data management scenarios."""
    
    def __init__(self):
        self.scenarios: Dict[str, Dict[str, Any]] = {}
        self.coordinators: Dict[str, WorkflowCoordinator] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
    
    async def create_scenario(self, request: str, config: Dict[str, Any]) -> str:
        """Create a new scenario from a request."""
        scenario_id = str(uuid.uuid4())
        
        # Initialize coordinator for this scenario
        coordinator = WorkflowCoordinator(llm_type=config.get('llm_type'))
        coordinator.setup_agents(
            db_url=config.get('db_url'),
            file_base_path=config.get('file_base_path')
        )
        
        # Store scenario information
        self.scenarios[scenario_id] = {
            'request': request,
            'status': 'initialized',
            'config': config,
            'created_at': datetime.now().isoformat(),
            'steps': [],
            'current_step': None,
            'dependencies': set()
        }
        
        self.coordinators[scenario_id] = coordinator
        self._locks[scenario_id] = asyncio.Lock()
        
        return scenario_id
    
    async def execute_scenario(self, scenario_id: str) -> Dict[str, Any]:
        """Execute a specific scenario."""
        if scenario_id not in self.scenarios:
            raise ValueError(f"Scenario {scenario_id} not found")
        
        async with self._locks[scenario_id]:
            try:
                self.scenarios[scenario_id]['status'] = 'running'
                coordinator = self.coordinators[scenario_id]
                
                # Execute the workflow
                results = await coordinator.process_request(
                    self.scenarios[scenario_id]['request']
                )
                
                # Update scenario status
                self.scenarios[scenario_id].update({
                    'status': 'completed',
                    'results': results,
                    'completed_at': datetime.now().isoformat()
                })
                
                return results
            except Exception as e:
                self.scenarios[scenario_id].update({
                    'status': 'failed',
                    'error': str(e),
                    'failed_at': datetime.now().isoformat()
                })
                raise
    
    async def execute_multiple_scenarios(self, scenario_ids: list[str]) -> Dict[str, Any]:
        """Execute multiple scenarios concurrently."""
        tasks = []
        for scenario_id in scenario_ids:
            if scenario_id in self.scenarios:
                task = asyncio.create_task(
                    self.execute_scenario(scenario_id),
                    name=f"scenario-{scenario_id}"
                )
                tasks.append(task)
        
        results = {}
        completed = await asyncio.gather(*tasks, return_exceptions=True)
        
        for scenario_id, result in zip(scenario_ids, completed):
            if isinstance(result, Exception):
                results[scenario_id] = {
                    'status': 'failed',
                    'error': str(result)
                }
            else:
                results[scenario_id] = {
                    'status': 'completed',
                    'results': result
                }
        
        return results
    
    def get_scenario_status(self, scenario_id: str) -> Optional[Dict[str, Any]]:
        """Get the current status of a scenario."""
        return self.scenarios.get(scenario_id)
    
    def get_all_scenarios(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all scenarios."""
        return self.scenarios
    
    async def cleanup_scenario(self, scenario_id: str):
        """Clean up resources for a specific scenario."""
        if scenario_id in self.coordinators:
            await self.coordinators[scenario_id].cleanup()
            del self.coordinators[scenario_id]
            del self._locks[scenario_id]
            self.scenarios[scenario_id]['status'] = 'cleaned_up'

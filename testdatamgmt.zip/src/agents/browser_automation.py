from typing import Dict, Any, Optional
from playwright.async_api import async_playwright, Browser, Page
from agents.base_agent import BaseAgent
from llm.factory import LLMFactory
from config.llm_config import LLMConfig

class BrowserAutomationAgent(BaseAgent):
    """Agent responsible for browser automation tasks."""
    
    def __init__(self, llm_type: str = None):
        super().__init__()
        self.browser: Optional[Browser] = None
        self.page: Optional[Page] = None
        
        # Initialize LLM
        config = LLMConfig()
        self.llm = LLMFactory.create_llm(
            llm_type or config.config["default_llm"],
            **config.get_llm_config(llm_type)
        )
    
    async def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Execute browser automation tasks based on the current state."""
        action = state.get('action')
        if not action:
            return {'error': 'No action specified'}
        
        actions = {
            'navigate': self._navigate,
            'extract': self._extract_data,
            'interact': self._interact,
            'validate': self._validate_page
        }
        
        if action not in actions:
            return {'error': f'Invalid action: {action}'}
        
        try:
            if not self.browser:
                await self._init_browser()
            
            result = await actions[action](state)
            return {**state, **result}
        except Exception as e:
            return {**state, 'error': str(e)}
        
    async def _init_browser(self):
        """Initialize the browser instance."""
        playwright = await async_playwright().start()
        self.browser = await playwright.chromium.launch(headless=True)
        self.page = await self.browser.new_page()
    
    async def _navigate(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Navigate to a URL and wait for page load."""
        url = state.get('url')
        if not url:
            return {'error': 'No URL provided'}
        
        await self.page.goto(url)
        await self.page.wait_for_load_state('networkidle')
        
        return {
            'status': 'success',
            'current_url': self.page.url,
            'title': await self.page.title()
        }
    
    async def _extract_data(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract data from the current page based on selectors or rules."""
        selectors = state.get('selectors', {})
        if not selectors:
            return {'error': 'No selectors provided'}
        
        data = {}
        for key, selector in selectors.items():
            try:
                elements = await self.page.query_selector_all(selector)
                data[key] = [await el.text_content() for el in elements]
            except Exception as e:
                data[key] = f'Error: {str(e)}'
        
        return {'extracted_data': data}
    
    async def _interact(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Interact with elements on the page."""
        interactions = state.get('interactions', [])
        if not interactions:
            return {'error': 'No interactions provided'}
        
        results = []
        for interaction in interactions:
            action_type = interaction.get('type')
            selector = interaction.get('selector')
            value = interaction.get('value')
            
            try:
                if action_type == 'click':
                    await self.page.click(selector)
                elif action_type == 'type':
                    await self.page.fill(selector, value)
                elif action_type == 'select':
                    await self.page.select_option(selector, value)
                
                results.append({
                    'action': action_type,
                    'selector': selector,
                    'status': 'success'
                })
            except Exception as e:
                results.append({
                    'action': action_type,
                    'selector': selector,
                    'status': 'error',
                    'error': str(e)
                })
        
        return {'interaction_results': results}
    
    async def _validate_page(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Validate page content or state against expected conditions."""
        validation_rules = state.get('validation_rules', [])
        if not validation_rules:
            return {'error': 'No validation rules provided'}
        
        page_content = await self.page.content()
        
        # Use LLM to validate page content
        validation_prompt = f"""
        Validate the following page content against these rules:
        Rules: {validation_rules}
        Content: {page_content[:2000]}  # Truncated for LLM context window
        
        Return a JSON object with:
        1. is_valid (boolean)
        2. errors (list of string errors if any)
        """
        
        validation_result = await self.llm.generate(validation_prompt)
        return {'validation_result': validation_result}
    
    async def cleanup(self):
        """Clean up browser resources."""
        if self.page:
            await self.page.close()
        if self.browser:
            await self.browser.close()

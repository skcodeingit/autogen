from typing import Dict, Any, List
from pathlib import Path
import json
import csv
from agents.base_agent import BaseAgent
from llm.factory import LLMFactory
from config.llm_config import LLMConfig

class FileOperationsAgent(BaseAgent):
    """Agent responsible for file operations including reading, writing, and validation."""
    
    def __init__(self, base_path: str = None, llm_type: str = None):
        super().__init__()
        self.base_path = Path(base_path) if base_path else Path.cwd()
        
        # Initialize LLM
        config = LLMConfig()
        self.llm = LLMFactory.create_llm(
            llm_type or config.config["default_llm"],
            **config.get_llm_config(llm_type)
        )
    
    async def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Execute file operations based on the current state."""
        operation = state.get('operation')
        if not operation:
            return {'error': 'No operation specified'}
        
        operations = {
            'read': self._read_file,
            'write': self._write_file,
            'validate': self._validate_file,
            'transform': self._transform_file
        }
        
        if operation not in operations:
            return {'error': f'Invalid operation: {operation}'}
        
        try:
            result = await operations[operation](state)
            return {**state, **result}
        except Exception as e:
            return {**state, 'error': str(e)}
    
    async def _read_file(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Read file content based on file type."""
        file_path = self.base_path / state.get('file_path', '')
        if not file_path.exists():
            return {'error': f'File not found: {file_path}'}
        
        file_type = file_path.suffix.lower()
        content = None
        
        if file_type == '.json':
            with open(file_path, 'r') as f:
                content = json.load(f)
        elif file_type == '.csv':
            with open(file_path, 'r') as f:
                reader = csv.DictReader(f)
                content = list(reader)
        else:
            with open(file_path, 'r') as f:
                content = f.read()
        
        return {'content': content, 'file_type': file_type}
    
    async def _write_file(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Write content to file."""
        file_path = self.base_path / state.get('file_path', '')
        content = state.get('content')
        file_type = file_path.suffix.lower()
        
        if not content:
            return {'error': 'No content provided'}
        
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        if file_type == '.json':
            with open(file_path, 'w') as f:
                json.dump(content, f, indent=2)
        elif file_type == '.csv':
            if not isinstance(content, list):
                return {'error': 'Content must be a list of dictionaries for CSV'}
            if not content:
                return {'error': 'Empty content for CSV'}
            
            with open(file_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=content[0].keys())
                writer.writeheader()
                writer.writerows(content)
        else:
            with open(file_path, 'w') as f:
                f.write(str(content))
        
        return {'status': 'success', 'written_file': str(file_path)}
    
    async def _validate_file(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Validate file content against schema or rules."""
        content = state.get('content')
        validation_rules = state.get('validation_rules', {})
        
        if not content or not validation_rules:
            return {'error': 'Missing content or validation rules'}
        
        # Use LLM to validate complex rules
        validation_prompt = f"""
        Validate the following content against these rules:
        Content: {content}
        Rules: {validation_rules}
        
        Return a JSON object with:
        1. is_valid (boolean)
        2. errors (list of string errors if any)
        """
        
        validation_result = await self.llm.generate(validation_prompt)
        return {'validation_result': validation_result}
    
    async def _transform_file(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Transform file content based on rules."""
        content = state.get('content')
        transform_rules = state.get('transform_rules', {})
        
        if not content or not transform_rules:
            return {'error': 'Missing content or transform rules'}
        
        # Use LLM to transform content
        transform_prompt = f"""
        Transform the following content according to these rules:
        Content: {content}
        Rules: {transform_rules}
        
        Return the transformed content in the same format as the input.
        """
        
        transformed_content = await self.llm.generate(transform_prompt)
        return {'transformed_content': transformed_content}

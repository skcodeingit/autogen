from typing import Dict, Any
from sqlalchemy import create_engine, text
from .base_agent import BaseAgent
from llm.factory import LLMFactory
from config.llm_config import LLMConfig

class DatabaseReaderAgent(BaseAgent):
    """Agent responsible for reading data from various database systems."""
    
    def __init__(self, db_url: str, llm_type: str = None):
        super().__init__()
        # Initialize LLM
        config = LLMConfig()
        self.llm = LLMFactory.create_llm(llm_type or config.config["default_llm"],
                                       **config.get_llm_config(llm_type))
        
        # Initialize database connection
        self.engine = create_engine(db_url)
    
    async def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute database queries based on the current state.
        
        Args:
            state (Dict[str, Any]): Current workflow state containing query requirements
            
        Returns:
            Dict[str, Any]: Updated state with query results
        """
        system = state.get('target_system')
        query_type = state.get('query_type')
        parameters = state.get('parameters', {})
        
        if not system or not query_type:
            return {'error': 'Missing required state parameters: target_system or query_type'}
        
        # Define query based on system and type
        query = self._get_query_for_system(system, query_type)
        
        try:
            with self.engine.connect() as connection:
                result = connection.execute(text(query), parameters)
                data = [dict(row) for row in result]
                
            return {
                'status': 'success',
                'data': data,
                'system': system,
                'query_type': query_type
            }
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e),
                'system': system,
                'query_type': query_type
            }
    
    def _get_query_for_system(self, system: str, query_type: str) -> str:
        """Generate appropriate SQL query based on system and query type."""
        queries = {
            'employer_system': {
                'refresh': 'SELECT * FROM employers WHERE last_updated > ?',
                'validation': 'SELECT * FROM employer_validation_rules'
            },
            'policy_system': {
                'refresh': 'SELECT * FROM policies WHERE employer_id = ?',
                'validation': 'SELECT * FROM policy_validation_rules'
            },
            'claims_system': {
                'refresh': 'SELECT * FROM claims WHERE policy_id = ?',
                'validation': 'SELECT * FROM claims_validation_rules'
            }
        }
        
        return queries.get(system, {}).get(query_type, '')

from typing import Dict, Any
from abc import ABC, abstractmethod

class BaseAgent(ABC):
    """Base class for all agents in the system."""
    
    def __init__(self):
        self.state = {}
    
    @abstractmethod
    async def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run the agent's core logic.
        
        Args:
            state (Dict[str, Any]): Current state of the workflow
            
        Returns:
            Dict[str, Any]: Updated state after agent execution
        """
        pass
    
    def update_state(self, state: Dict[str, Any]):
        """Update agent's internal state."""
        self.state.update(state)

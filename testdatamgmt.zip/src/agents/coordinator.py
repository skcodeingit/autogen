from typing import Dict, Any, List
import asyncio
from typing import Dict, Any, List, Callable, Awaitable
from llm.factory import LLMFactory
from config.llm_config import LLMConfig
from agents.database_reader import DatabaseReaderAgent
from agents.file_operations import FileOperationsAgent
from agents.browser_automation import BrowserAutomationAgent
from workflows.human_approval import HumanApprovalManager, ApprovalStatus

class WorkflowCoordinator:
    """Coordinates the execution of multiple agents in a workflow."""
    
    def __init__(self, llm_type: str = None):
        # Initialize LLM for coordination
        config = LLMConfig()
        self.llm = LLMFactory.create_llm(
            llm_type or config.config["default_llm"],
            **config.get_llm_config(llm_type)
        )
        
        # Initialize agents
        self.db_agent = None
        self.file_agent = None
        self.browser_agent = None
        
        # Initialize human approval manager
        self.approval_manager = HumanApprovalManager()
        self.scenario_id = None
    
    def setup_agents(self, db_url: str = None, file_base_path: str = None):
        """Initialize agents with configuration."""
        if db_url:
            self.db_agent = DatabaseReaderAgent(db_url)
        if file_base_path:
            self.file_agent = FileOperationsAgent(file_base_path)
        self.browser_agent = BrowserAutomationAgent()
    
    async def process_request(self, request: str, scenario_id: str) -> Dict[str, Any]:
        """Process a natural language request and orchestrate agents."""
        self.scenario_id = scenario_id
        
        # Use LLM to parse request and create workflow
        workflow_prompt = f"""
        Analyze the following request and create a workflow plan:
        Request: {request}
        
        Return a JSON object with:
        1. steps (list of actions with agent type and parameters)
        2. dependencies (list of step dependencies)
        3. validation_points (list of validation steps)
        4. approval_points (list of steps requiring human approval)
        """
        
        workflow_plan = await self.llm.generate(workflow_prompt)
        return await self._execute_workflow(workflow_plan)
    
    async def _execute_workflow(self, workflow_plan: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the workflow based on the plan."""
        steps = workflow_plan.get('steps', [])
        dependencies = workflow_plan.get('dependencies', {})
        approval_points = workflow_plan.get('approval_points', [])
        
        # Create a map of step functions
        step_functions: Dict[str, Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]] = {}
        for step in steps:
            step_id = step['id']
            if step_id in approval_points:
                step_functions[step_id] = self._create_approval_node(step)
            else:
                step_functions[step_id] = self._create_agent_node(step)
        
        # Execute steps in dependency order
        results = {}
        executed = set()
        
        async def execute_step(step_id: str, state: Dict[str, Any]) -> Dict[str, Any]:
            try:
                result = await step_functions[step_id](state)
                results[step_id] = result
                executed.add(step_id)
                return result
            except Exception as e:
                results[step_id] = {"error": str(e)}
                executed.add(step_id)
                raise
        
        while len(executed) < len(steps):
            # Find all steps that can be executed (dependencies satisfied)
            executable_steps = []
            for step in steps:
                step_id = step['id']
                if step_id not in executed:
                    deps = dependencies.get(step_id, [])
                    if all(dep in executed for dep in deps):
                        executable_steps.append(step_id)
            
            if not executable_steps:
                raise ValueError("Circular dependency detected or no executable steps found")
            
            # Execute steps in parallel if they don't depend on each other
            tasks = [execute_step(step_id, results) for step_id in executable_steps]
            await asyncio.gather(*tasks, return_exceptions=True)
        
        return results
    
    def _create_agent_node(self, step: Dict[str, Any]):
        """Create a node function for an agent step."""
        agent_type = step['agent_type']
        
        async def node_func(state: Dict[str, Any]) -> Dict[str, Any]:
            if agent_type == 'database':
                return await self.db_agent.run(state)
            elif agent_type == 'file':
                return await self.file_agent.run(state)
            elif agent_type == 'browser':
                return await self.browser_agent.run(state)
            raise ValueError(f"Unknown agent type: {agent_type}")
        
        return node_func
    
    def _create_approval_node(self, step: Dict[str, Any]):
        """Create a node function that includes human approval."""
        agent_node = self._create_agent_node(step)
        
        async def approval_node(state: Dict[str, Any]) -> Dict[str, Any]:
            # Execute the agent step
            step_result = await agent_node(state)
            
            # Request human approval
            approval_context = {
                "step_id": step['id'],
                "step_type": step['agent_type'],
                "input_state": state,
                "output_state": step_result
            }
            
            approval_result = await self.approval_manager.get_approval(
                scenario_id=self.scenario_id,
                step_id=step['id'],
                context=approval_context,
                timeout=300  # 5 minutes timeout
            )
            
            if approval_result["status"] != ApprovalStatus.APPROVED.value:
                raise ValueError(
                    f"Step {step['id']} was not approved. "
                    f"Status: {approval_result['status']}, "
                    f"Comments: {approval_result['comments']}"
                )
            
            return step_result
        
        return approval_node
    
    async def cleanup(self):
        """Clean up resources."""
        if self.browser_agent:
            await self.browser_agent.cleanup()

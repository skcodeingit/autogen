import sys
import traceback
from typing import Dict, Any
import json
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import httpx

print("Starting application...")

class ApprovalDialog(tk.Toplevel):
    """Dialog for handling approval decisions."""
    
    def __init__(self, request_data: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.request_data = request_data
        self.result = None
        self.comments_text = ""
        self.init_ui()
    
    def init_ui(self):
        self.title('Approval Request')
        self.geometry('500x600')
        
        # Context information
        form_frame = ttk.Frame(self, padding="10")
        form_frame.pack(fill=tk.X)
        
        ttk.Label(form_frame, text="Step ID:").grid(row=0, column=0, sticky=tk.W)
        ttk.Label(form_frame, text=self.request_data['step_id']).grid(row=0, column=1, sticky=tk.W)
        
        ttk.Label(form_frame, text="Scenario ID:").grid(row=1, column=0, sticky=tk.W)
        ttk.Label(form_frame, text=self.request_data['scenario_id']).grid(row=1, column=1, sticky=tk.W)
        
        ttk.Label(form_frame, text="Created:").grid(row=2, column=0, sticky=tk.W)
        ttk.Label(form_frame, text=self.request_data['created_at']).grid(row=2, column=1, sticky=tk.W)
        
        # Context viewer
        ttk.Label(self, text="Context:").pack(anchor=tk.W, padx=10)
        context_text = scrolledtext.ScrolledText(self, height=10)
        context_text.pack(fill=tk.BOTH, expand=True, padx=10)
        context_text.insert('1.0', json.dumps(self.request_data['context'], indent=2))
        context_text.configure(state='disabled')
        
        # Comments field
        ttk.Label(self, text="Comments:").pack(anchor=tk.W, padx=10)
        self.comments = scrolledtext.ScrolledText(self, height=5)
        self.comments.pack(fill=tk.BOTH, expand=True, padx=10)
        
        # Buttons
        button_frame = ttk.Frame(self, padding="10")
        button_frame.pack(fill=tk.X)
        
        self.approve_btn = ttk.Button(button_frame, text='Approve', command=self.handle_approve)
        self.approve_btn.pack(side=tk.LEFT, padx=5)
        
        self.reject_btn = ttk.Button(button_frame, text='Reject', command=self.handle_reject)
        self.reject_btn.pack(side=tk.LEFT, padx=5)
    
    def handle_approve(self):
        self.comments_text = self.comments.get('1.0', tk.END)
        self.result = True
        self.destroy()
    
    def handle_reject(self):
        self.comments_text = self.comments.get('1.0', tk.END)
        self.result = False
        self.destroy()

class NewScenarioDialog(tk.Toplevel):
    """Dialog for creating new scenarios."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.result = None
        self.init_ui()
    
    def init_ui(self):
        self.title('Create New Scenario')
        self.geometry('400x500')
        
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Request text with character limit hint
        ttk.Label(main_frame, text="Request (max 500 characters):").pack(anchor=tk.W)
        self.request_text = scrolledtext.ScrolledText(main_frame, height=5)
        self.request_text.pack(fill=tk.BOTH, expand=True)
        # Add a label for character count
        self.char_count_label = ttk.Label(main_frame, text="0/500 characters")
        self.char_count_label.pack(anchor=tk.E)
        # Bind text changes to update character count
        self.request_text.bind('<<Modified>>', self.update_char_count)
        
        # Model selection
        model_frame = ttk.Frame(main_frame)
        model_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(model_frame, text="Model:").pack(side=tk.LEFT)
        self.llm_type = ttk.Combobox(model_frame, values=['llama2'])
        self.llm_type.pack(side=tk.LEFT, padx=(5, 0))
        self.llm_type.set('llama2')  # Default to llama2
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10,0))
        
        ttk.Button(button_frame, text="OK", command=self.handle_ok).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=self.handle_cancel).pack(side=tk.LEFT)
    
    def handle_ok(self):
        self.result = self.get_data()
        self.destroy()
    
    def handle_cancel(self):
        self.result = None
        self.destroy()
    
    def update_char_count(self, event=None):
        if self.request_text:
            # Reset the modified flag
            self.request_text.edit_modified(False)
            # Get current character count
            current_text = self.request_text.get('1.0', tk.END).strip()
            char_count = len(current_text)
            self.char_count_label.config(text=f"{char_count}/500 characters")
            # Warn if over limit
            if char_count > 500:
                self.char_count_label.config(foreground='red')
            else:
                self.char_count_label.config(foreground='black')

    def get_data(self) -> Dict[str, Any]:
        request_text = self.request_text.get('1.0', tk.END).strip()
        if len(request_text) > 500:
            messagebox.showerror('Error', 'Request text exceeds 500 character limit')
            return None
        return {
            "request": request_text,
            "config": {
                "model": self.llm_type.get()
            }
        }

class MainWindow(tk.Tk):
    """Main application window."""
    
    def __init__(self):
        print("Initializing MainWindow...")
        super().__init__()
        print("Setting up API URL...")
        self.api_url = "http://localhost:8000"
        print("Initializing UI...")
        self.init_ui()
        print("Starting refresh timer...")
        self.start_refresh_timer()
        print("MainWindow initialization complete.")
    
    def init_ui(self):
        try:
            print("Setting window properties...")
            self.title('Test Data Management')
            self.geometry('1200x800+100+100')
            
            print("Creating main frame...")
            main_frame = ttk.Frame(self, padding="10")
            main_frame.pack(fill=tk.BOTH, expand=True)
            
            print("Creating notebook widget...")
            notebook = ttk.Notebook(main_frame)
            notebook.pack(fill=tk.BOTH, expand=True)
            
            print("Setting up approvals tab...")
            approvals_frame = ttk.Frame(notebook, padding="5")
            notebook.add(approvals_frame, text='Pending Approvals')
            
            self.approvals_tree = ttk.Treeview(approvals_frame, columns=(
                'Request ID', 'Scenario ID', 'Step ID', 'Created At'
            ), show='headings')
            
            # Set up columns
            for col in self.approvals_tree['columns']:
                self.approvals_tree.heading(col, text=col)
                self.approvals_tree.column(col, width=150)
            
            self.approvals_tree.pack(fill=tk.BOTH, expand=True)
            self.approvals_tree.bind('<Double-1>', self.handle_approval_request)
            
            print("Setting up scenarios tab...")
            scenarios_frame = ttk.Frame(notebook, padding="5")
            notebook.add(scenarios_frame, text='Scenarios')
            
            # Add new scenario button
            new_scenario_btn = ttk.Button(scenarios_frame, text='New Scenario', command=self.create_new_scenario)
            new_scenario_btn.pack(fill=tk.X, pady=(0, 5))
            
            self.scenarios_tree = ttk.Treeview(scenarios_frame, columns=(
                'Scenario ID', 'Status', 'Created At'
            ), show='headings')
            
            # Set up columns
            for col in self.scenarios_tree['columns']:
                self.scenarios_tree.heading(col, text=col)
                self.scenarios_tree.column(col, width=150)
            
            self.scenarios_tree.pack(fill=tk.BOTH, expand=True)
            
            print("Performing initial data load...")
            self.refresh_data()
            
            print("UI initialization complete.")
        except Exception as e:
            print("Error initializing UI:", str(e))
            traceback.print_exc()
            raise
    
    def start_refresh_timer(self):
        """Start timer to refresh data periodically."""
        try:
            print("Starting refresh timer...")
            self.refresh_data()  # Initial refresh
            self.after(5000, self.start_refresh_timer)  # Schedule next refresh
            print("Timer started successfully.")
        except Exception as e:
            print("Error setting up refresh timer:", str(e))
            traceback.print_exc()
    
    def refresh_data(self):
        """Refresh all data from the API."""
        print("Refreshing data from API...")
        try:
            print("Loading approvals...")
            self.load_approvals()
            print("Loading scenarios...")
            self.load_scenarios()
            print("Data refresh complete.")
        except Exception as e:
            print("Error during data refresh:", str(e))
            traceback.print_exc()
    
    def load_approvals(self):
        """Load pending approvals from API."""
        try:
            print("Fetching approvals from API...")
            response = httpx.get(f"{self.api_url}/approvals/pending", timeout=5.0)
            response.raise_for_status()
            approvals = response.json()
            
            print(f"Received {len(approvals)} approval requests")
            for item in self.approvals_tree.get_children():
                self.approvals_tree.delete(item)
                
            for req_id, data in approvals.items():
                self.approvals_tree.insert('', tk.END, values=(
                    req_id,
                    data['scenario_id'],
                    data['step_id'],
                    data['created_at']
                ))
            
            print("Approvals loaded successfully")
        except httpx.TimeoutException:
            print("API request timed out")
            messagebox.showwarning('Connection Error', 'Failed to connect to API server - request timed out')
        except httpx.HTTPStatusError as e:
            print(f"API request failed with status {e.response.status_code}")
            messagebox.showwarning('API Error', f'Server returned error: {e.response.text}')
        except Exception as e:
            print("Error loading approvals:", str(e))
            traceback.print_exc()
            messagebox.showwarning('Error', f'Failed to load approvals: {str(e)}')
    
    def load_scenarios(self):
        """Load scenarios from API."""
        try:
            print("\n=== Loading Scenarios ===")
            print("\nMaking GET request to /scenarios endpoint...")
            response = httpx.get(f"{self.api_url}/scenarios", timeout=5.0)
            
            print("\nAPI Response:")
            print("-------------")
            print(f"Status Code: {response.status_code}")
            print(f"Headers: {dict(response.headers)}")
            print("\nResponse Body:")
            try:
                print(json.dumps(response.json(), indent=2))
            except:
                print(response.text)
            
            response.raise_for_status()
            scenarios = response.json()
            
            print(f"\nProcessing {len(scenarios) if scenarios else 0} scenarios")
                
            # Clear existing items
            print("\nClearing existing tree items")
            for item in self.scenarios_tree.get_children():
                self.scenarios_tree.delete(item)

            if scenarios is None:
                print("\nWarning: Received null scenarios data")
                return

            print("\nDetermining data format...")
            print(f"Data type: {type(scenarios)}")
            
            if isinstance(scenarios, dict):
                print("Processing dictionary format")
                items = scenarios.items()
            elif isinstance(scenarios, list):
                print("Processing list format")
                items = ((scenario.get('id', str(i)), scenario) for i, scenario in enumerate(scenarios))
            else:
                error_msg = f"Unexpected scenarios data format: {type(scenarios)}"
                print(f"\nError: {error_msg}")
                raise ValueError(error_msg)

            for scenario_id, data in items:
                print(f"\nProcessing scenario:")
                print(f"ID: {scenario_id}")
                print(f"Raw data: {json.dumps(data, indent=2)}")
                
                # Extract data with detailed logging
                status = data.get('status', 'unknown')
                created_at = data.get('created_at', 'unknown')
                
                print(f"Extracted fields:")
                print(f"- Status: {status}")
                print(f"- Created At: {created_at}")
                
                self.scenarios_tree.insert('', tk.END, values=(
                    scenario_id,
                    status,
                    created_at
                ))
                print("Successfully added to tree view")
            
            print("Scenarios loaded successfully")
        except httpx.TimeoutException:
            print("API request timed out")
            messagebox.showwarning('Connection Error', 'Failed to connect to API server - request timed out')
        except httpx.HTTPStatusError as e:
            print(f"API request failed with status {e.response.status_code}")
            messagebox.showwarning('API Error', f'Server returned error: {e.response.text}')
        except Exception as e:
            print("Error loading scenarios:", str(e))
            traceback.print_exc()
            messagebox.showwarning('Error', f'Failed to load scenarios: {str(e)}')
    
    def create_new_scenario(self):
        """Open dialog to create new scenario."""
        dialog = NewScenarioDialog(self)
        self.wait_window(dialog)
        if dialog.result is not None:
            try:
                print("\n=== Creating New Scenario ===")
                data = dialog.result
                if data is None:  # Check if data is None due to validation failure
                    print("Data validation failed - no data to send")
                    return
                
                print("\nRequest Data:")
                print("-------------")
                print(json.dumps(data, indent=2))
                
                try:
                    print("\nSending request to API...")
                    response = httpx.post(f"{self.api_url}/scenarios", json=data, timeout=5.0)
                    
                    print("\nAPI Response:")
                    print("-------------")
                    print(f"Status Code: {response.status_code}")
                    print(f"Headers: {dict(response.headers)}")
                    print("\nResponse Body:")
                    try:
                        print(json.dumps(response.json(), indent=2))
                    except:
                        print(response.text)
                        
                    response.raise_for_status()
                    print("\nScenario created successfully")
                    messagebox.showinfo('Success', 'Scenario created successfully')
                    self.refresh_data()
                    
                except httpx.TimeoutException:
                    error_msg = "Failed to connect to API server - request timed out"
                    print(f"\nError: {error_msg}")
                    messagebox.showwarning('Connection Error', error_msg)
                    
                except httpx.HTTPStatusError as e:
                    print(f"\nHTTP Error Details:")
                    print(f"Status Code: {e.response.status_code}")
                    print(f"Headers: {dict(e.response.headers)}")
                    
                    try:
                        error_json = e.response.json()
                        print("\nValidation Error Details:")
                        print(json.dumps(error_json, indent=2))
                        
                        if isinstance(error_json, dict):
                            if 'detail' in error_json:
                                if isinstance(error_json['detail'], list):
                                    # Handle Pydantic validation errors
                                    error_details = []
                                    for error in error_json['detail']:
                                        field = ' -> '.join(str(loc) for loc in error.get('loc', []))
                                        msg = error.get('msg', '')
                                        error_details.append(f"Field '{field}': {msg}")
                                    error_msg = "\n".join(error_details)
                                else:
                                    error_msg = str(error_json['detail'])
                            else:
                                error_msg = str(error_json)
                        else:
                            error_msg = str(error_json)
                    except:
                        print("\nError Response (Raw):")
                        print(e.response.text)
                        error_msg = e.response.text
                        
                    error_display = f"""API Error Details:
Status: {e.response.status_code}
Message: {error_msg}

Please check the terminal for full error logs."""
                    print(f"\nShowing error dialog with message: {error_msg}")
                    messagebox.showerror('API Error', error_display)
            except Exception as e:
                print("Error creating scenario:", str(e))
                traceback.print_exc()
                messagebox.showerror('Error', f'Failed to create scenario: {str(e)}')
    
    def handle_approval_request(self, event):
        """Handle clicking on an approval request."""
        tree = event.widget
        item = tree.selection()[0]
        request_id = tree.item(item)['values'][0]
        
        try:
            print("Fetching approval request details...")
            response = httpx.get(f"{self.api_url}/approvals/pending", timeout=5.0)
            response.raise_for_status()
            approvals = response.json()
            
            if request_id in approvals:
                print(f"Opening approval dialog for request {request_id}")
                dialog = ApprovalDialog(approvals[request_id], self)
                self.wait_window(dialog)
                
                if dialog.result is not None:
                    print("Submitting approval decision...")
                    response = httpx.post(
                        f"{self.api_url}/approvals/{request_id}",
                        json={
                            "approved": dialog.result,
                            "comments": dialog.comments_text.strip()
                        },
                        timeout=5.0
                    )
                    response.raise_for_status()
                    print("Approval decision submitted successfully")
                    self.refresh_data()
                else:
                    print("Approval dialog cancelled")
        except httpx.TimeoutException:
            print("API request timed out")
            messagebox.showwarning('Connection Error', 'Failed to connect to API server - request timed out')
        except httpx.HTTPStatusError as e:
            print(f"API request failed with status {e.response.status_code}")
            messagebox.showwarning('API Error', f'Server returned error: {e.response.text}')
        except Exception as e:
            print("Error handling approval:", str(e))
            traceback.print_exc()
            messagebox.showwarning('Error', f'Failed to handle approval: {str(e)}')

def main():
    try:
        print("Creating main window...")
        window = MainWindow()
        print("Starting main loop...")
        window.mainloop()
    except Exception as e:
        print("Error in main:", str(e))
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()

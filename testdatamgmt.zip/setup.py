from setuptools import setup, find_packages

setup(
    name="tdm",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "langchain",
        "langgraph",
        "python-dotenv",
        "chromadb",
        "sqlalchemy",
        "playwright",
        "beautifulsoup4",
        "python-jose[cryptography]",
        "fastapi",
        "uvicorn",
        "langchain-community",
        "PyQt6",
        "httpx",
        "requests"
    ]
)

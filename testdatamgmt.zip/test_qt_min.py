import os
import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton
from PyQt6.QtCore import QCoreApplication, QLibraryInfo

# Set up Qt plugin path
plugin_path = os.path.join(os.path.dirname(os.path.dirname(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath))), "plugins")
print(f"Plugin path: {plugin_path}")
if os.path.exists(plugin_path):
    print(f"Plugin path exists: {plugin_path}")
    if not plugin_path in os.environ.get('QT_PLUGIN_PATH', ''):
        os.environ['QT_PLUGIN_PATH'] = plugin_path

# Enable debug output and check for qwindows.dll
os.environ['QT_DEBUG_PLUGINS'] = '1'

# Check for qwindows.dll
qwindows_path = os.path.join(plugin_path, "platforms", "qwindows.dll")
print(f"Looking for qwindows.dll at: {qwindows_path}")
if os.path.exists(qwindows_path):
    print(f"qwindows.dll found at: {qwindows_path}")
else:
    print("qwindows.dll not found!")
    print("Available files in plugins dir:")
    for root, dirs, files in os.walk(plugin_path):
        print(f"\nDirectory: {root}")
        for file in files:
            print(f"  {file}")

QCoreApplication.setAttribute(QCoreApplication.ApplicationAttribute.AA_UseDesktopOpenGL)

print("Starting application...")
app = QApplication(sys.argv)

print("Creating window...")
window = QMainWindow()
window.setGeometry(100, 100, 200, 200)

button = QPushButton("Click me", window)
button.setGeometry(50, 50, 100, 30)

window.show()
print("Window shown")

import logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("Qt")
logger.setLevel(logging.DEBUG)

print("Starting event loop...")
ret = app.exec()
print(f"Event loop returned: {ret}")

sys.exit(ret)

import sys
import os
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel
from PyQt6.QtCore import QLibraryInfo

# Add Qt plugins path
qt_plugin_path = os.path.join(os.path.dirname(sys.executable), "Lib", "site-packages", "PyQt6", "Qt6", "plugins")
os.environ['QT_PLUGIN_PATH'] = qt_plugin_path
os.environ['QT_DEBUG_PLUGINS'] = '1'

print(f"Using QT_PLUGIN_PATH: {qt_plugin_path}")
print(f"Qt6 prefix path: {QLibraryInfo.path(QLibraryInfo.LibraryPath.PrefixPath)}")
print(f"Qt6 plugin path: {QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)}")

class TestWindow(QMainWindow):
    def __init__(self):
        print("Creating window...")
        super().__init__()
        self.setWindowTitle("PyQt6 Test")
        self.setGeometry(100, 100, 300, 200)
        label = QLabel("Hello World!", self)
        label.move(110, 80)
        print("Window created.")

if __name__ == '__main__':
    try:
        print("Creating application...")
        app = QApplication(sys.argv)
        print(f"Available styles: {app.styles()}")
        print("Creating window instance...")
        window = TestWindow()
        print("Showing window...")
        window.show()
        print("Starting event loop...")
        sys.exit(app.exec())
    except Exception as e:
        print(f"Error: {e}")
        raise

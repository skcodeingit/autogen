import os
import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton
from PySide6.QtCore import QCoreApplication, QLibraryInfo

# Get and print Qt paths
print(f"Qt Plugin Path: {QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)}")
print(f"Libraries Path: {QLibraryInfo.path(QLibraryInfo.LibraryPath.LibrariesPath)}")
print(f"Prefix Path: {QLibraryInfo.path(QLibraryInfo.LibraryPath.PrefixPath)}")

# Ensure plugin path is set
plugins_path = QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)
os.environ['QT_PLUGIN_PATH'] = plugins_path
print(f"Setting QT_PLUGIN_PATH to: {plugins_path}")

# Enable plugin debugging
os.environ['QT_DEBUG_PLUGINS'] = '1'

print("Starting application...")
app = QApplication(sys.argv)

print("Creating window...")
window = QMainWindow()
window.setGeometry(100, 100, 200, 200)
window.setWindowTitle("Test Window")

button = QPushButton("Click me", window)
button.setGeometry(50, 50, 100, 30)

window.show()
print("Window shown")

print("Starting event loop...")
ret = app.exec()
print(f"Event loop returned: {ret}")

sys.exit(ret)

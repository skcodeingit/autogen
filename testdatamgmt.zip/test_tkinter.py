import tkinter as tk
from tkinter import ttk

def main():
    root = tk.Tk()
    root.title("Tkinter Test")
    
    # Create a label
    label = ttk.Label(root, text="Hello, Tkinter!")
    label.pack(padx=20, pady=20)
    
    # Create a button
    button = ttk.Button(root, text="Click Me!")
    button.pack(padx=20, pady=10)
    
    root.mainloop()

if __name__ == "__main__":
    main()

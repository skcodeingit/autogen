import asyncio
from pathlib import Path
from typing import Dict, Any
from scenarios.manager import ScenarioManager

async def main():
    # Initialize the scenario manager
    manager = ScenarioManager()
    
    # Example scenarios
    scenarios = [
        {
            "request": """
            Refresh test data for employer ABC Corp:
            1. Export current production data for employer ID ABC123
            2. Validate employer structure and employee counts
            3. Transform data for test environment
            4. Load into test environment
            5. Verify data integrity
            """,
            "config": {
                "db_url": "sqlite:///prod_mirror.db",
                "file_base_path": "./data/abc_corp",
                "llm_type": "ollama"
            }
        },
        {
            "request": """
            Prepare test data for new disability claim testing:
            1. Find active policy for employer XYZ Corp
            2. Select 5 eligible employees
            3. Generate sample disability claims
            4. Load claims into test environment
            5. Verify claim processing workflow
            """,
            "config": {
                "db_url": "sqlite:///prod_mirror.db",
                "file_base_path": "./data/xyz_corp",
                "llm_type": "ollama"
            }
        },
        {
            "request": """
            Update test environment with new plan master data:
            1. Extract updated plan definitions from production
            2. Validate plan structure changes
            3. Transform for test environment
            4. Update test environment
            5. Verify plan calculations
            """,
            "config": {
                "db_url": "sqlite:///prod_mirror.db",
                "file_base_path": "./data/plan_master",
                "llm_type": "ollama"
            }
        }
    ]
    
    # Create scenarios
    scenario_ids = []
    for scenario in scenarios:
        scenario_id = await manager.create_scenario(
            request=scenario["request"],
            config=scenario["config"]
        )
        scenario_ids.append(scenario_id)
        print(f"Created scenario: {scenario_id}")
    
    # Execute scenarios concurrently
    print("\nExecuting scenarios...")
    results = await manager.execute_multiple_scenarios(scenario_ids)
    
    # Print results
    print("\nScenario Results:")
    for scenario_id, result in results.items():
        print(f"\nScenario {scenario_id}:")
        print(f"Status: {result['status']}")
        if result['status'] == 'failed':
            print(f"Error: {result['error']}")
        else:
            print("Steps completed:")
            for step in result['results'].get('steps', []):
                print(f"- {step['action']}: {step['status']}")
    
    # Cleanup
    print("\nCleaning up resources...")
    for scenario_id in scenario_ids:
        await manager.cleanup_scenario(scenario_id)

if __name__ == "__main__":
    asyncio.run(main())
